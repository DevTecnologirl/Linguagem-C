/* LISTA DE FUN��ES - QUEST�O 5 - VERS�O1
   Fa�a uma fun��o que verifique se uma data � v�lida ou n�o,
   retornando os valores VERDADEIRO (data v�lida) ou FALSO (data inv�lida).
   Os par�metros da fun��o s�o tr�s n�meros inteiros,
   correspondentes a dia, m�s e ano da data a ser verificada.
*/

#include <stdio.h>
#include <stdlib.h>

int verificaData(int d, int m, int a);
int verificaAno(int a);

main()
{   int dia,mes,ano;
    printf("Informe o dia: ");
    scanf("%d",&dia);
    printf("Informe o m�s: ");
    scanf("%d",&mes);
    printf("Informe o ano: ");
    scanf("%d",&ano);
    if (verificaData(dia,mes,ano))
    { printf("A data � v�lida!\n"); }
    else
    { printf("A data � inv�lida!\n"); }    
    system("pause");
}

int verificaAno(int a)
{   if(a%4==0)
    {  printf("Ano bissexto!\n");
       return 1;}
    else
    {  printf("Ano n�o � bissexto!\n");
       return 0; }
}

int verificaData(int d,int m,int a)
{   
    if((a>0)&&(a<=2013))
    {  if((m>=1)&&(m<=12))
       {  if(m==2)
          { if(verificaAno(a))
            {  //vai at� o dia 29;
               if ((d>=1)&&(d<=29))
               { return 1;        }
               else
               {   printf("Dia inv�lido!\n");
                   return 0;         }
            }
            else
            {  //vai at� o dia 28;
               if ((d>=1)&&(d<=28))
               { return 1;        }
               else
               {   printf("Dia inv�lido!\n");
                   return 0;         }              
            }
          }
          else
          {   if((m==1)||(m==3)||(m==5)||(m==7)||(m==8)||(m==10)||(m==12))
              {   //vai at� o dia 31;
                  if ((d>=1)&&(d<=31))
                  { return 1;        }
                   else
                   {   printf("Dia inv�lido!\n");
                       return 0;         }                            
              }
              else
              {   //vai at� o dia 30;
                  if ((d>=1)&&(d<=30))
                  { return 1;        }
                  else
                  {   printf("Dia inv�lido!\n");
                      return 0;         }              
                 }
          }           
          
       }
       else
       {  printf("M�s inv�lido!\n");
          return 0; }
    }
    else
    {  printf("Ano inv�lido!\n");
       return 0; }
}



