/* LISTA DE FUN��ES - QUEST�O 2
   Fa�a um programa que mostre uma tela com as seguintes op��es:
   1 � Calcular M�dia, 2 � Calcular Somat�rio, 3 � Achar Maior Nota,
   4 � Achar Menor Nota, 0 � Finalizar o programa. Cada uma das op��es
   chamar� um procedimento com a devida funcionalidade. Para fins de c�lculo,
   estes testes se basear�o em um vetor chamado notas de 10 posi��es que deve
   ser preenchido pelo usu�rio.
*/


#include <stdio.h>
#include <stdlib.h>

float notas[10];
float somat=0;

void media();
void somatorio();
void maiorNota();
void menorNota();

main()
{     int i,op;

      for(i=0;i<10;i++)
      {   printf("Informe a nota%d: ",i+1);
          scanf("%f",&notas[i]);    }

      printf("MENU DE OP��ES:\n");
      printf("1. Calcular M�dia\n");
      printf("2. Calcular Somat�rio\n");
      printf("3. Achar Maior Nota\n");
      printf("4. Achar Menor Nota\n");
      printf("5. Finalizar Programa\n\n");
      printf("Escolha uma das op��es acima: ");
      scanf("%d",&op);
      switch(op)
      {      case 1: media();
                     break;
             case 2: somatorio();
                     break;
             case 3: maiorNota();
                     break;
             case 4: menorNota();
                     break;
             case 5: exit(0);
                     break;
             default: printf("\nOp��o inv�lida!\n");
      }
      system("pause");
}

void media()
{    //int i;
     float media=0;
     /*for(i=0;i<10;i++)
     {  media = media + notas[i];     }
     media=media/10;*/
     somatorio();
     media=somat/10;
     printf("M�dia das notas = %.2f\n",media);
}

void somatorio()
{    int i;
     float soma=0;
     for(i=0;i<10;i++)
     {  soma = soma + notas[i];     }
     printf("Somat�rio das notas = %.2f\n",soma);
     somat=soma;
}

void maiorNota()
{    int i;
     float maior=0;
     for(i=0;i<10;i++)
     {  if (notas[i]>maior)
        {  maior=notas[i]; }
     }   
     printf("Maior nota = %.2f\n",maior);
}

void menorNota()
{    int i;
     float menor=10;
     for(i=0;i<10;i++)
     {  if (notas[i]<menor)
        {  menor=notas[i]; }
     }   
     printf("Menor nota = %.2f\n",menor);
}
