/* LISTA DE FUN��ES - QUEST�O 7
   Fa�a um programa que:
   a) Leia uma lista de no m�ximo 10 n�meros, carregando-os em um vetor, com
      final dos dados indicado pelo n�mero 0.
   b) Apresente os n�meros pares ap�s a ordena��o.
   c) Apresente o total de n�meros �mpares lidos.
   d) Utilize rotinas para leitura, ordena��o e apresenta��o dos resultados.
*/

#include <stdio.h>
#include <stdlib.h>

int numeros[10];

void leitura();
void ordenacao();
void listaPares();
void listaImpares();

main()
{    leitura();
     listaPares();
     listaImpares();
     system("pause");      
}

void leitura()
{    int cont=0;
     printf("Informe um n�mero: ");
     scanf("%d",&numeros[cont]);
     while((cont<9)&&(numeros[cont]!=0))
     {   cont=cont+1;
         printf("Informe um n�mero: ");
         scanf("%d",&numeros[cont]);
         
     }
}

void ordenacao()
{    int aux;
     for(int i=0;i<10;i++)
     {   for (int j=0;j<9;j++)
         { if(numeros[j]>numeros[j+1])
           {  aux=numeros[j+1];
              numeros[j+1]=numeros[j];
              numeros[j]=aux;
           }
         }
     }
}

void listaPares()
{    ordenacao();
     printf("\n\nVetor ordenado: ");
     for (int i=0;i<10;i++)
     {printf("%d ",numeros[i]);}

     printf("\n\nN�meros pares: ");
     for(int i=0;i<10;i++)
     {   if (numeros[i]%2==0) 
         { printf("%d ",numeros[i]); }
     }
}

void listaImpares()
{    printf("\n\nN�meros �mpares: ");
     for(int i=0;i<10;i++)
     {   if (numeros[i]%2!=0) 
         { printf("%d ",numeros[i]); }
     }
}
