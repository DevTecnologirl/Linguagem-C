/* LISTA DE FUN��ES - QUEST�O 3
   Fa�a uma fun��o que receba um n�mero inteiro N, maior ou igual a 0,
   e retorne o valor de seu fatorial (N!).
   O fatorial de um n�mero N � calculado por 1 * 2 * 3 * ...* N.
   O valor do fatorial de 0 �, por defini��o, igual a 1.
*/

#include <stdio.h>
#include <stdlib.h>

double fatorial(int n);

main()
{     
      int numero;
      printf("Informe um n�mero inteiro: ");
      scanf("%d",&numero);
      printf("Fatorial do n�mero %d � %.0lf!\n",numero,fatorial(numero));
      system("pause");
}

double fatorial(int n)
{   
    double fat=1;
    for(int i=1;i<=n;i++)
    {   fat=fat*i;    }
    return fat;
}
