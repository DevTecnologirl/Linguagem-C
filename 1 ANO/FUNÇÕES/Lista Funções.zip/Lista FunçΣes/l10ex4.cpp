/* LISTA DE FUN��ES - QUEST�O 4
   Fa�a uma fun��o que receba dois n�meros inteiros I e J,
   e calcule a express�o I!/J!*(I-J)!. Use a fun��o fatorial,
   enunciada no exerc�cio anterior.
*/


#include <stdio.h>
#include <stdlib.h>

int fatorial(int num);
int resultado(int i,int j);

main()
{
     int n1,n2;
     printf("Informe dois n�meros: ");
     scanf("%d%d",&n1,&n2);
     printf("O resultado � %d\n",resultado(n1,n2));
     system("pause");
}          

int fatorial(int num)
{   int i,f=0,fat=1;
     if ((num==0)||(num==1))
     {   fat=1;  }
     else
     {    for(i=2;i<=num;i++)
          {   f=(fat*i);
              fat=f;
          }
     }     
     return fat;
}

int resultado(int i,int j)
{
    return (fatorial(i)/(fatorial(j)*fatorial(i-j)));
}
