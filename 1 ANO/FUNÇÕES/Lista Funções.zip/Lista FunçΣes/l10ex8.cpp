/* LISTA DE FUN��ES - QUEST�O 8
   Fa�a um programa que mostre uma tela com as seguintes op��es:
   1 � Dobro, 2 � Triplo, 3 � Metade, 4 � Quadrado, 5 � Cubo, 6 � Raiz Quadrada,
   7 � Raiz C�bica, 8 � M�dulo, 9 � Inverso e 0 � Sair do Programa.
   Cada uma das op��es chamar� um procedimento com a devida funcionalidade.
   Para fins de c�lculo, estes testes se basear�o em um n�mero inteiro N informado
   pelo usu�rio.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void dobro(int n);
void triplo(int n);
void metade(int n);
void quadrado(int n);
void cubo(int n);
void raizQuadrada(int n);
void raizCubica(int n);
void modulo(int n);
void inverso(int n);

main()
{     int op,n;
      printf("Informe um n�mero inteiro: ");
      scanf("%d",&n);
      printf("*** MENU DE OP��ES ***\n");
      printf("1. Dobro\n");
      printf("2. Triplo\n");
      printf("3. Metade\n");
      printf("4. Quadrado\n");
      printf("5. Cubo\n");
      printf("6. Raiz Quadrada\n");
      printf("7. Raiz C�bica\n");
      printf("8. M�dulo\n");
      printf("9. Inverso\n");
      printf("0. Sair do Programa\n\n");
      printf("Escolha uma op��o: ");
      scanf("%d",&op);
      switch(op)
      {     case 1: dobro(n);
                    break;
            case 2: triplo(n);
                    break;
            case 3: metade(n);
                    break;
            case 4: quadrado(n);
                    break;
            case 5: cubo(n);
                    break;
            case 6: raizQuadrada(n);
                    break;
            case 7: raizCubica(n);
                    break;
            case 8: modulo(n);
                    break;
            case 9: inverso(n);
                    break;
            case 0: exit(0);
                    break;
            default: printf("Op��o inv�lida!\n\n");
                     break;
      }
      system("pause");
}

void dobro(int n)
{    printf("Dobro de %d = %d\n",n,n*2); }

void triplo(int n)
{    printf("Triplo de %d = %d\n",n,n*3); }

void metade(int n)
{    printf("Metade de %d = %.2f\n",n,(float)n/2); }

void quadrado(int n)
{    printf("Quadrado de %d = %.2f\n",n,pow(n,2)); }

void cubo(int n)
{    printf("Cubo de %d = %.2f\n",n,pow(n,3)); }

void raizQuadrada(int n)
{    printf("Raiz Quadrada de %d = %.2f\n",n,sqrt(n)); }

void raizCubica(int n)
{    printf("Raiz C�bica de %d = %.2f\n",n,cbrt(n)); }

void modulo(int n)
{    if(n<0)
     { printf("M�dulo de %d = %d\n",n,n*-1); }
     else
     { printf("M�dulo de %d = %d\n",n,n); }
}
     
void inverso(int n)
{    if(n==0)
     { printf("Zero n�o possui inverso\n",n,n*-1); }
     else
     { printf("Inverso de %d = %.2f\n",n,(float)1/n); }
}
