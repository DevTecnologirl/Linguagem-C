/* LISTA DE FUN��ES - QUEST�O 6
   Fa�a uma fun��o que verifique se um n�mero inteiro, recebido como par�metro,
   � v�lido ou n�o. O n�mero tem oito d�gitos (ABCDEFGH) onde H deve ser igual
   ao resto da divis�o de (1*G)+(2*F)+(3*E)+(4*D)+(5*C)+(6*B)+(7*A) por 10 para
   que o n�mero seja v�lido. A fun��o deve retornar os valores VERDADEIRO
   (n�mero v�lido) ou FALSO (n�mero inv�lido).
*/

#include <stdio.h>
#include <stdlib.h>

int teste(int numero[8]);

main()
{
      int vetor[8];
      for(int i=0;i<8;i++)
      {   printf("Informe um n�mero inteiro: ");
          scanf("%d",&vetor[i]);
      }
      if(teste(vetor)==1)
         printf("N�mero v�lido!\n");
      else
         printf("N�mero inv�lido!\n");
      system("pause");
}

int teste(int numero[8])
{   int soma=0;
    for(int i=0;i<7;i++)
    {   soma=soma+(numero[i]*(i+1)); }
    if (numero[7]==(soma%10))
       return 1;
    else
       return 0;
}
