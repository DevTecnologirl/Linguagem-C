/* LISTA DE FUN��ES - QUEST�O 5 - VERS�O2
   Fa�a uma fun��o que verifique se uma data � v�lida ou n�o,
   retornando os valores VERDADEIRO (data v�lida) ou FALSO (data inv�lida).
   Os par�metros da fun��o s�o tr�s n�meros inteiros,
   correspondentes a dia, m�s e ano da data a ser verificada.
*/

#include <stdlib.h>
#include <stdio.h>

int verifica(int d, int m, int a)
{   if(a>=0 && a<=2016)
    {  //ano v�lido
       if(m>=1 && m<=12)
       {   //m�s v�lido
           if(m==1||m==3||m==5||m==7||m==8||m==10||m==12)
           {   if(d>=1 && d<=31)
               {  return 1; }
               else
               {  return 0; }
           }
           else
           {   if (m==4||m==6||m==9||m==11)
               {   if(d>=1 && d<=30)
                   {  return 1; }
                   else
                   {  return 0; }
               }
               else
               {  /* M�s de fevereiro - verificar se o ano � bissexto
                     Tente dividir o ano por 4. Se o resto for diferente de 0, ou seja, se for indivis�vel por 4, ele n�o � bissexto. Se for divis�vel por 4, � preciso verificar se o ano acaba em 00 (zero duplo). Em caso negativo, o ano � bissexto. Se terminar em 00, � preciso verificar se � divis�vel por 400. Se sim, � bissexto; se n�o, � um ano normal. 
                     Achou confuso? Vejamos na pr�tica como funciona a regra. Tomemos 2008 como exemplo. 2008 � um n�mero divis�vel por 4 (o resultado � 502) e que n�o acaba em 00. Logo, esse ano � bissexto. J� o ano 1900 n�o foi bissexto: � divis�vel por 4, termina em 00, mas n�o � divis�vel por 400. O ano 2000, por sua vez, foi bissexto: � divis�vel por 4, termina em 00 e � divis�vel por 400.
                     se for bissexto termina em 29, caso contr�rio termina em 28
                  */
                  if(a%4==0)
                  {  if(a%100==0)
                     {  if (a%400==0)
                        { //ano � bissexto
                          if(d>=1&&d<=29)
                          { return 1; }
                          else
                          { return 0; }
                        }
                        else
                        { //ano n�o � bissexto
                          if (d>=1&&d<=28)
                          { return 1; }
                          else
                          { return 0; }
                        }
                     }
                     else
                     {  //ano � bissexto
                        if(d>=1&&d<=29)
                        { return 1; }
                        else
                        { return 0; }
                     }
                  }
                  else
                  {  //ano n�o bissexto
                     if (d>=1&&d<=28)
                     { return 1; }
                     else
                     { return 0; }
                  }  
               }
           }
       }
       else
       {  //m�s inv�lido
          return 0;
       }
    }
    else
    {  //ano inv�lido
       return 0;
    }

}

main()
{     int dia,mes,ano;
      printf("Informe o dia: ");
      scanf("%d",&dia);
      printf("Informe o m�s: ");
      scanf("%d",&mes);
      printf("Informe o ano: ");
      scanf("%d",&ano);
      if(verifica(dia,mes,ano))
         printf("Data v�lida!");
      else
         printf("Data inv�lida!");   
      system("pause");
}
