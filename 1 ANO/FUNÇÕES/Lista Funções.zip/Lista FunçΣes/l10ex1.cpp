/* LISTA DE FUN��ES - QUEST�O 1
   Fa�a um programa que mostre o resultado do c�lculo das �reas do tri�ngulo,
   quadrado e c�rculo, onde de in�cio o usu�rio escolhe o tipo de �rea que
   deseja calcular e depois executa o procedimento referente � op��o escolhida.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void triangulo();
void quadrado();
void circulo();

main()
{
      int op;
      printf("*** MENU DE OP��ES ***\n");
      printf("1. �rea do Tri�ngulo\n");
      printf("2. �rea do Quadrado\n");
      printf("3. �rea do C�rculo\n");
      printf("0. Finalizar Programa\n\n");      
      printf("Escolha uma op��o: ");
      scanf("%d",&op);
      switch(op)
      {      case 1: triangulo();
                     break;
             case 2: quadrado();
                     break;      
             case 3: circulo();
                     break;      
             case 0: exit(0);
                     break;      
             default: printf("Op��o inv�lida!\n");
                      break;        
      }
      system("pause");
}

void triangulo()
{    float base,altura;
     printf("Informe a base: ");
     scanf("%f",&base);
     printf("Informe a altura: ");
     scanf("%f",&altura);
     printf("�rea do tri�ngulo = %.2f\n",(base*altura)/2);
}

void quadrado()
{    float lado;
     printf("Informe o lado: ");
     scanf("%f",&lado);
     printf("�rea do quadrado = %.2f\n",pow(lado,2));
}

void circulo()
{    float raio;
     printf("Informe o raio: ");
     scanf("%f",&raio);
     printf("�rea do c�rculo = %.2f\n",(3.1416*pow(raio,2)));
}

