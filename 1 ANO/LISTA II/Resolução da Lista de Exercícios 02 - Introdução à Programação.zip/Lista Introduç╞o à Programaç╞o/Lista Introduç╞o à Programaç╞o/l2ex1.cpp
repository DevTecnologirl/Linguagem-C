#include <stdio.h>
#include <stdlib.h>
main()
{
      printf("Ol� mundo!\n");
      system("pause");
}     
